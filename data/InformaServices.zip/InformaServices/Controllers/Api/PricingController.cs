﻿using System;
using System.Configuration;
using System.Web.Http;
using System.Web.Http.Cors;
using ms8.code.Loggers;
using ms8.code.Mappers;
using ms8.code.Models;
using ms8.code.Pricing.Endpoints;
using ms8.code.Pricing.Repositories;
using MongoDB.Driver.Builders;

namespace InformaServices.Controllers.Api
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class PricingController : ApiController
    {
        [HttpGet]
        public PricingDetails GetPrices(string isbn)
        {
            if (ConfigurationManager.AppSettings["UseRealServices"] == "true")
            {
                return GetApiPrices(isbn);
            }

            return GetCachedPrices(isbn);
        }

        private static PricingDetails GetCachedPrices(string isbn)
        {
            var result =
                PriceHarvestRepository.MongoCollection().FindOne(Query<PricingDetails>.EQ(a => a.IsbnNumber, isbn));

            if (result == null)
            {
                return new PricingDetails { Value = Math.Round(Decimal.Parse(isbn) / 100000000000, 2), Currency = "&pound;" };
            }

            return result;
        }

        private static PricingDetails GetApiPrices(string isbn)
        {
            PricingService service = new PricingService(new ConsoleLog());

            var result = service.FindPriceByIsbn(isbn);

            return PricingMapper.Map(isbn, result);
        }
    }
}

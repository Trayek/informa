﻿using System;
using System.Collections.Generic;
using Microsoft.Owin;
using Owin;

[assembly: OwinStartup(typeof(InformaServices.Startup))]

namespace InformaServices
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            
        }
    }
}
